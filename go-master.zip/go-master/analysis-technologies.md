#### **Weka (Java Framework)**

* [Weka (MOOC)](http://www.cs.waikato.ac.nz/ml/weka/mooc/dataminingwithweka/) for Data Mining

#### **Lua** (Libraries)
 * [Torch7](http://torch.ch/) scientific computing framework with wide support for machine learning algorithms

#### **R** [here](r-resources.md)

NB: The core curriculum centers on python-based techniques and technologies
